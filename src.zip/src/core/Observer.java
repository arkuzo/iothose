package core;

public interface Observer {

    void handleEvent(Data data);

}
