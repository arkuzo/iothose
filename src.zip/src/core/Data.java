package core;

public interface Data {
}
