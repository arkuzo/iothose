package Devices.Data;

import core.Data;

public interface DeviceData extends Data {

    String toString();
}
